Explicit image blur er jonno ekhane "nsfw.tflite" naam e model file rakho.
Model: input 224x224 RGB; output 5 class (drawings, hentai, neutral, porn, sexy) ba 2 class (safe, nsfw).
File na thakle image blur bondho thake (baki shob feature cholbe).
