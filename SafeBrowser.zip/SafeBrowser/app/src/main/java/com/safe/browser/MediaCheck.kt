package com.safe.browser

import android.util.LruCache
import android.webkit.WebResourceRequest
import java.net.HttpURLConnection
import java.net.URL

/** Response header (Content-Type) dekhe unknown site er video/stream dhore. HEAD request pathay, page WebView nijei load kore. */
object MediaCheck {
    private val cache = LruCache<String, Boolean>(500)
    private val safeExt = setOf("js", "css", "png", "jpg", "jpeg", "gif", "webp", "svg", "ico", "avif", "woff", "woff2", "ttf", "otf", "map")

    private fun videoType(ct: String?): Boolean {
        val c = (ct ?: "").lowercase().substringBefore(';').trim()
        return c.startsWith("video/") || c in Rules.videoMime
    }

    /** Background thread e cholbe (shouldInterceptRequest). Kono error hole page pass kore. */
    fun isVideo(r: WebResourceRequest, cookie: String?): Boolean {
        if (r.method != "GET") return false
        val u = r.url
        if (u.scheme != "http" && u.scheme != "https") return false
        val acc = r.requestHeaders["Accept"] ?: ""
        if (acc.startsWith("image/") || acc.startsWith("text/css")) return false
        if ((u.path ?: "").substringAfterLast('.', "").lowercase() in safeExt) return false
        val key = u.toString()
        cache.get(key)?.let { return it }
        val res = try {
            val c = URL(key).openConnection() as HttpURLConnection
            c.requestMethod = "HEAD"; c.connectTimeout = 3000; c.readTimeout = 3000; c.instanceFollowRedirects = true
            r.requestHeaders.forEach { (k, v) -> if (!k.equals("Accept-Encoding", true)) c.setRequestProperty(k, v) }
            if (cookie != null) c.setRequestProperty("Cookie", cookie)
            val t = c.contentType; c.disconnect(); videoType(t)
        } catch (e: Exception) { false }
        cache.put(key, res)
        return res
    }
}
