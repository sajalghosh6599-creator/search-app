@file:Suppress("DEPRECATION")

package com.safe.browser

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.app.DownloadManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.widget.doAfterTextChanged
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayInputStream

class Tab(val web: WebView, val incognito: Boolean, var group: String? = null)

class MainActivity : AppCompatActivity() {
    private val tabs = mutableListOf<Tab>()
    private var cur = 0
    private val closed = mutableListOf<String>()
    private var desktop = false
    private var picker: ValueCallback<Array<Uri>>? = null
    private lateinit var urlBox: EditText
    private lateinit var bar: ProgressBar
    private lateinit var holder: FrameLayout
    private lateinit var tabBtn: Button
    private val prefs by lazy { getSharedPreferences("sb", MODE_PRIVATE) }
    private val home = "https://www.google.com/"

    private fun cw() = tabs[cur].web
    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        fun btn(t: String, f: () -> Unit) = Button(this, null, android.R.attr.borderlessButtonStyle).apply {
            text = t; textSize = 18f; minWidth = 0; minimumWidth = 0; setOnClickListener { f() }
        }
        urlBox = EditText(this).apply {
            setSingleLine(); imeOptions = EditorInfo.IME_ACTION_GO
            inputType = InputType.TYPE_TEXT_VARIATION_URI; setSelectAllOnFocus(true)
            setOnEditorActionListener { v, _, _ -> go(v.text.toString()); v.clearFocus(); true }
        }
        val menuBtn = btn("⋮") {}
        menuBtn.setOnClickListener { menu(menuBtn) }
        val top = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            addView(btn("⌂") { nav(home) })
            addView(urlBox, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            addView(menuBtn)
        }
        bar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply { max = 100; visibility = View.GONE }
        holder = FrameLayout(this)
        tabBtn = btn("⧉1") { tabList() }
        val bottom = LinearLayout(this).apply {
            listOf(
                btn("◀") { if (cw().canGoBack()) cw().goBack() },
                btn("▶") { if (cw().canGoForward()) cw().goForward() },
                btn("⟳") { cw().reload() },
                btn("☆") { addBookmark() },
                tabBtn
            ).forEach { addView(it, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)) }
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; fitsSystemWindows = true
            addView(top)
            addView(bar, LinearLayout.LayoutParams(-1, dp(3)))
            addView(holder, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(bottom)
        }
        setContentView(root)
        Thread {
            ImageGuard.init(applicationContext)
            if (!ImageGuard.ready) runOnUiThread { toast("Image blur model nai (assets/nsfw.tflite)") }
        }.start()
        newTab(intent?.dataString)
    }

    // ---------- Navigation + rules ----------
    private fun go(t0: String) {
        val t = t0.trim(); if (t.isEmpty()) return
        nav(
            if (t.startsWith("http://") || t.startsWith("https://")) t
            else if (t.contains(".") && !t.contains(" ")) "https://$t"
            else "https://www.google.com/search?safe=active&q=" + Uri.encode(t)
        )
    }

    private fun nav(u: String) { val w = cw(); if (!handle(Uri.parse(u), w)) w.loadUrl(u) }

    private fun blocked(w: WebView, why: String) = w.loadDataWithBaseURL(
        null, "<html><body style='font:20px sans-serif;text-align:center;padding:60px 20px'><h2>🚫 Blocked</h2><p>$why</p></body></html>",
        "text/html", "utf-8", null
    )

    private fun openApp(pkg: String, u: Uri) = try {
        startActivity(Intent(Intent.ACTION_VIEW, u).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
    } catch (e: Exception) { false }

    /** true = amra handle korechi (page load korbe na). */
    private fun handle(u: Uri, w: WebView): Boolean {
        val sc = u.scheme ?: return false
        if (sc != "http" && sc != "https") {
            if (sc in setOf("about", "blob", "data", "javascript")) return false
            if (sc == "file" || sc == "content") { blocked(w, "Local file block kora"); return true }
            try { // tel:, mailto:, sms:, geo:, market:, intent: ... shob app e redirect
                val i = if (sc == "intent") Intent.parseUri(u.toString(), Intent.URI_INTENT_SCHEME) else Intent(Intent.ACTION_VIEW, u)
                i.addCategory(Intent.CATEGORY_BROWSABLE); i.selector = null; i.component = null
                startActivity(i)
            } catch (e: Exception) { toast("Ei link khulte app nai") }
            return true
        }
        if (Rules.isYoutube(Rules.host(u))) { if (!openApp("com.google.android.youtube", u)) blocked(w, "YouTube app install nai"); return true }
        if (Rules.isMaps(u) && openApp("com.google.android.apps.maps", u)) return true
        Rules.blockReason(u)?.let { blocked(w, it); return true }
        Rules.forceSafe(u)?.let { w.loadUrl(it.toString()); return true }
        return false
    }

    // ---------- Tabs ----------
    private fun newTab(u: String?, inc: Boolean = false) {
        val w = WebView(this); setup(w)
        tabs.add(Tab(w, inc)); select(tabs.size - 1); nav(u ?: home)
    }

    private fun select(i: Int) {
        cur = i; holder.removeAllViews(); holder.addView(cw())
        urlBox.setText(cw().url ?: ""); tabBtn.text = "⧉${tabs.size}"
    }

    private fun closeTab(i: Int) {
        holder.removeAllViews()
        val t = tabs.removeAt(i)
        t.web.url?.let { if (!t.incognito && it.startsWith("http")) closed.add(0, it) }
        t.web.destroy()
        if (tabs.isEmpty()) newTab(null) else select(minOf(if (i < cur) cur - 1 else cur, tabs.size - 1))
    }

    private fun applyUa(w: WebView) {
        w.settings.apply {
            userAgentString = if (desktop) "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
            else WebSettings.getDefaultUserAgent(this@MainActivity).replace("; wv", "").replace(" Version/4.0", "")
            useWideViewPort = desktop; loadWithOverviewMode = desktop
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setup(w: WebView) {
        w.settings.apply {
            javaScriptEnabled = true; domStorageEnabled = true; mediaPlaybackRequiresUserGesture = true
            allowFileAccess = false; allowContentAccess = false
            setSupportZoom(true); builtInZoomControls = true; displayZoomControls = false
        }
        applyUa(w)
        CookieManager.getInstance().setAcceptThirdPartyCookies(w, true)
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT))
            WebViewCompat.addDocumentStartJavaScript(w, Rules.JS, setOf("*"))

        w.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest) = if (r.isForMainFrame) handle(r.url, v) else false
            override fun shouldInterceptRequest(v: WebView, r: WebResourceRequest): WebResourceResponse? =
                if (Rules.blockedRequest(r.url) || (r.isForMainFrame && Rules.forceSafe(r.url) != null) || MediaCheck.isVideo(r, CookieManager.getInstance().getCookie(r.url.toString())))
                    WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream("Block kora".toByteArray()))
                else ImageGuard.process(r, CookieManager.getInstance().getCookie(r.url.toString()))
            override fun onPageStarted(v: WebView, u: String, f: Bitmap?) {
                if (v === cw()) urlBox.setText(u); v.evaluateJavascript(Rules.JS, null)
            }
            override fun onPageFinished(v: WebView, u: String) {
                v.evaluateJavascript(Rules.JS, null)
                if (u.startsWith("http") && tabs.firstOrNull { it.web === v }?.incognito == false) addHistory(v.title, u)
            }
            override fun doUpdateVisitedHistory(v: WebView, u: String, r: Boolean) {
                val x = Uri.parse(u)
                if (x.scheme?.startsWith("http") == true && (Rules.forceSafe(x) != null || Rules.blockReason(x) != null)) handle(x, v)
                else if (v === cw()) urlBox.setText(u)
            }
        }
        w.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                if (v === cw()) { bar.progress = p; bar.visibility = if (p < 100) View.VISIBLE else View.GONE }
            }
            override fun onShowFileChooser(v: WebView, cb: ValueCallback<Array<Uri>>, p: FileChooserParams): Boolean {
                picker?.onReceiveValue(null); picker = cb
                return try { startActivityForResult(p.createIntent(), 77); true } catch (e: Exception) { picker = null; false }
            }
            override fun onPermissionRequest(r: PermissionRequest) { r.deny() }
            override fun onGeolocationPermissionsShowPrompt(o: String, cb: GeolocationPermissions.Callback) { cb.invoke(o, false, false) }
        }
        w.setDownloadListener { u, ua, cd, mime, _ ->
            val name = URLUtil.guessFileName(u, cd, mime)
            if (Rules.badDownload(name, mime)) { toast("Video/APK download block kora"); return@setDownloadListener }
            try {
                val r = DownloadManager.Request(Uri.parse(u)).setMimeType(mime)
                    .addRequestHeader("User-Agent", ua)
                    .addRequestHeader("Cookie", CookieManager.getInstance().getCookie(u) ?: "")
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(DOWNLOAD_SERVICE) as DownloadManager).enqueue(r)
                toast("Download shuru: $name")
            } catch (e: Exception) { toast("Ei download kora gelo na") }
        }
    }

    override fun onActivityResult(rc: Int, res: Int, d: Intent?) {
        if (rc == 77) { picker?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, d)); picker = null }
        else super.onActivityResult(rc, res, d)
    }

    override fun onBackPressed() {
        val w = cw()
        if (w.canGoBack()) w.goBack() else if (tabs.size > 1) closeTab(cur) else super.onBackPressed()
    }

    // ---------- Menu ----------
    private fun menu(a: View) {
        val p = PopupMenu(this, a)
        listOf("New tab", "New Incognito tab", "Add tab to new group", "History", "Delete browsing data", "Site controls",
            "Downloads", "Bookmarks", "Recent tabs", "Share…", "Find in page", "Translate…", "Gemini", "Show Reading mode",
            "Install and create shortcut", "Desktop site").forEachIndexed { i, t -> p.menu.add(0, i, i, t) }
        p.menu.getItem(15).apply { isCheckable = true; isChecked = desktop }
        p.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                0 -> newTab(null)
                1 -> newTab(null, true)
                2 -> askText("Group er naam") { tabs[cur].group = it; toast("Group: $it") }
                3 -> listDialog("History", "h")
                4 -> clearAll()
                5 -> siteControls()
                6 -> startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
                7 -> listDialog("Bookmarks", "b")
                8 -> recent()
                9 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, cw().url), null))
                10 -> findDialog()
                11 -> cw().url?.let { nav("https://translate.google.com/translate?sl=auto&tl=bn&u=" + Uri.encode(it)) }
                12 -> newTab("https://gemini.google.com/app")
                13 -> cw().evaluateJavascript(Rules.READ, null)
                14 -> shortcut()
                15 -> { desktop = !desktop; tabs.forEach { applyUa(it.web) }; cw().reload() }
            }
            true
        }
        p.show()
    }

    private fun askText(t: String, f: (String) -> Unit) {
        val e = EditText(this)
        AlertDialog.Builder(this).setTitle(t).setView(e)
            .setPositiveButton("OK") { _, _ -> f(e.text.toString()) }.setNegativeButton("Cancel", null).show()
    }

    private fun findDialog() {
        val w = cw(); val e = EditText(this)
        e.doAfterTextChanged { w.findAllAsync(it.toString()) }
        val d = AlertDialog.Builder(this).setTitle("Find in page").setView(e)
            .setPositiveButton("Next", null).setNegativeButton("Close", null)
            .setOnDismissListener { w.clearMatches() }.create()
        d.show(); d.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener { w.findNext(true) }
    }

    private fun clearAll() {
        AlertDialog.Builder(this).setTitle("Browsing data delete?").setMessage("History, cache, cookies shob muche jabe")
            .setPositiveButton("Delete") { _, _ ->
                prefs.edit().remove("h").apply()
                CookieManager.getInstance().removeAllCookies(null); WebStorage.getInstance().deleteAllData()
                tabs.forEach { it.web.clearCache(true); it.web.clearFormData() }; toast("Done")
            }.setNegativeButton("Cancel", null).show()
    }

    private fun siteControls() {
        val u = cw().url ?: return; val x = Uri.parse(u); val h = x.host ?: return
        AlertDialog.Builder(this).setTitle(h)
            .setMessage("🔒 Location, camera, mic, notification: shob block\n🔒 Safe Search, video/APK block: lock kora")
            .setPositiveButton("Ei site er data muche felo") { _, _ ->
                val cm = CookieManager.getInstance()
                cm.getCookie(u)?.split(";")?.forEach { cm.setCookie(u, it.substringBefore("=").trim() + "=; Max-Age=0") }
                WebStorage.getInstance().deleteOrigin("${x.scheme}://$h"); toast("Done")
            }.setNegativeButton("Close", null).show()
    }

    private fun recent() {
        if (closed.isEmpty()) { toast("Kono recent tab nai"); return }
        AlertDialog.Builder(this).setTitle("Recent tabs")
            .setItems(closed.take(20).toTypedArray()) { _, i -> newTab(closed[i]) }.setNegativeButton("Close", null).show()
    }

    private fun tabList() {
        val labels = tabs.mapIndexed { i, t ->
            "${i + 1}. " + (if (t.incognito) "🕶 " else "") + (t.group?.let { "[$it] " } ?: "") + (t.web.title ?: t.web.url ?: "New tab")
        }.toMutableList()
        val d = AlertDialog.Builder(this).setTitle("Tabs (long-press = close)")
            .setAdapter(ArrayAdapter(this, android.R.layout.simple_list_item_1, labels), null)
            .setPositiveButton("+ New") { _, _ -> newTab(null) }.setNegativeButton("Close", null).create()
        d.show()
        d.listView.setOnItemClickListener { _, _, i, _ -> select(i); d.dismiss() }
        d.listView.setOnItemLongClickListener { _, _, i, _ -> closeTab(i); d.dismiss(); true }
    }

    // ---------- History / Bookmarks ----------
    private fun load(k: String): MutableList<Array<String>> {
        val a = JSONArray(prefs.getString(k, "[]"))
        return MutableList(a.length()) { val o = a.getJSONObject(it); arrayOf(o.getString("t"), o.getString("u")) }
    }

    private fun save(k: String, l: List<Array<String>>) {
        val a = JSONArray(); l.forEach { a.put(JSONObject().put("t", it[0]).put("u", it[1])) }
        prefs.edit().putString(k, a.toString()).apply()
    }

    private fun addHistory(t: String?, u: String) {
        val l = load("h"); if (l.firstOrNull()?.get(1) == u) return
        l.add(0, arrayOf(t ?: "", u)); save("h", l.take(300))
    }

    private fun addBookmark() {
        val u = cw().url ?: return; val l = load("b")
        if (l.none { it[1] == u }) { l.add(0, arrayOf(cw().title ?: "", u)); save("b", l); toast("Bookmark hoyeche") } else toast("Agei ache")
    }

    private fun listDialog(title: String, key: String) {
        val l = load(key)
        val ad = ArrayAdapter(this, android.R.layout.simple_list_item_1, l.map { it[0].ifBlank { it[1] } }.toMutableList())
        val d = AlertDialog.Builder(this).setTitle("$title (long-press = delete)").setAdapter(ad, null)
            .setNegativeButton("Close", null).setNeutralButton("Delete all") { _, _ -> save(key, emptyList()) }.create()
        d.show()
        d.listView.setOnItemClickListener { _, _, i, _ -> nav(l[i][1]); d.dismiss() }
        d.listView.setOnItemLongClickListener { _, _, i, _ -> l.removeAt(i); ad.remove(ad.getItem(i)); save(key, l); true }
    }

    private fun shortcut() {
        val u = cw().url ?: return
        val s = ShortcutInfoCompat.Builder(this, "s" + u.hashCode()).setShortLabel((cw().title ?: "Site").take(20))
            .setIcon(IconCompat.createWithResource(this, R.mipmap.ic_launcher))
            .setIntent(Intent(this, MainActivity::class.java).setAction(Intent.ACTION_VIEW).setData(Uri.parse(u))).build()
        ShortcutManagerCompat.requestPinShortcut(this, s, null)
    }
}
