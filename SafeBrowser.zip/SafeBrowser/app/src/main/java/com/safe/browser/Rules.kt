package com.safe.browser

import android.net.Uri

/** Shob block rule ekhane hardcoded. Kono ON/OFF toggle nai. */
object Rules {
    val videoExt = setOf("mp4", "m4v", "mkv", "webm", "avi", "mov", "flv", "3gp", "wmv", "m3u8", "mpd", "mpg", "mpeg", "ogv", "f4v")
    val apkExt = setOf("apk", "apks", "xapk", "apkm", "aab")
    val videoMime = setOf("application/vnd.android.package-archive", "application/x-mpegurl", "application/vnd.apple.mpegurl", "application/dash+xml", "audio/x-mpegurl", "audio/mpegurl", "video/mp2t")
    private val videoHosts = listOf("youtube.com", "youtu.be", "youtube-nocookie.com", "googlevideo.com", "vimeo.com", "dailymotion.com",
        "twitch.tv", "tiktok.com", "netflix.com", "hotstar.com", "primevideo.com", "jiocinema.com", "hulu.com", "disneyplus.com",
        "rumble.com", "kick.com", "bilibili.com", "jwplayer.com", "jwpsrv.com")
    private val adult = listOf("porn", "xvideo", "xnxx", "xhamster", "redtube", "youporn", "onlyfans", "hentai", "xxx", "nsfw",
        "chaturbate", "stripchat", "bongacams", "brazzers", "spankbang")

    // ---- Google, Bing, DuckDuckGo chara shob search engine block ----
    private val engineWords = listOf("yandex", "baidu", "sogou", "naver", "daum", "seznam", "ecosia", "qwant", "startpage", "mojeek", "kagi",
        "perplexity", "phind", "lycos", "dogpile", "excite", "gigablast", "yippy", "metager", "swisscows", "gibiru", "oceanhero", "givero",
        "searx", "whoogle", "presearch", "lukol", "marginalia")
    private val engineHosts = listOf("ask.com", "you.com", "yep.com", "so.com", "wiby.me", "infospace.com")
    private fun allowedEngine(h: String) = isGoogle(h) || h.endsWith("bing.com") || h.endsWith("duckduckgo.com")
    private fun otherEngine(u: Uri): Boolean {
        val h = host(u); val p = u.path ?: ""
        if (allowedEngine(h)) return false
        return engineWords.any { h.contains(it) } || engineHosts.any { h == it || h.endsWith(".$it") } ||
            h.startsWith("search.") || h.replace("research", "").contains("search") ||
            (h.endsWith("yahoo.com") && p.startsWith("/search"))
    }

    // ---- Unknown search engine: Safe Search force korte pari na, tai search-er moto URL hole block (fail-closed) ----
    private val siteSearchOk = listOf("wikipedia.org", "wikimedia.org", "amazon.in", "amazon.com", "flipkart.com", "github.com",
        "stackoverflow.com", "stackexchange.com", "linkedin.com")
    private val searchPaths = setOf("/search", "/web", "/results", "/serp", "/websearch", "/search/web", "/searchresults")
    private val queryKeys = listOf("q", "query", "p", "text", "wd", "keyword", "keywords", "search", "searchterm", "s")
    private fun unknownEngine(u: Uri): Boolean {
        val h = host(u)
        if (allowedEngine(h) || siteSearchOk.any { h == it || h.endsWith(".$it") }) return false
        val p = (u.path ?: "").lowercase().let { if (it.length > 1) it.trimEnd('/') else it }
        return p in searchPaths && queryKeys.any { u.getQueryParameter(it) != null }
    }

    // ---- Web proxy / VPN / unblock site block ----
    private val proxyWords = listOf("proxy", "vpn", "unblock", "anonymi", "bypass", "hidemy", "hidester", "whoer", "tunnelbear", "psiphon",
        "windscribe", "surfshark", "hotspotshield", "betternet", "cyberghost", "privateinternetaccess", "torproject", "tor2web",
        "ultrasurf", "croxy", "newipnow", "genmirror", "blockaway")
    private fun proxySite(u: Uri): Boolean {
        val h = host(u); val p = (u.path ?: "").lowercase()
        return proxyWords.any { h.contains(it) } || h == "hide.me" || h.endsWith(".hide.me") ||
            (p.contains("proxy") && (u.query ?: "").contains("http"))
    }

    /** Translate/cache/archive/AMP wrapper er bhitorer asol URL ber kore, jate bypass na hoy. */
    fun inner(u: Uri): Uri? {
        val h = host(u); val p = u.path ?: ""
        val s: String? = when {
            h.endsWith(".translate.goog") -> "https://" + h.removeSuffix(".translate.goog").replace("--", "\u0000").replace("-", ".").replace("\u0000", "-") + p
            h == "translate.google.com" && p.startsWith("/translate") -> u.getQueryParameter("u")
            h.endsWith("web.archive.org") -> Regex("/web/\\d+[a-z_]*/(.+)").find(p)?.groupValues?.get(1)
            h.endsWith("ampproject.org") || h.endsWith("ampproject.net") -> Regex("/[cv]/(?:s/)?(.+)").find(p)?.groupValues?.get(1)
            h == "webcache.googleusercontent.com" -> u.getQueryParameter("q")?.removePrefix("cache:")
            isGoogle(h) && p == "/url" -> u.getQueryParameter("q") ?: u.getQueryParameter("url")
            else -> null
        }
        return s?.let { Uri.parse(if (it.startsWith("http")) it else "https://$it") }
    }

    fun host(u: Uri) = (u.host ?: "").lowercase()
    fun isGoogle(h: String) = Regex("(^|\\.)google\\.[a-z.]+$").containsMatchIn(h)
    fun isYoutube(h: String) = h == "youtu.be" || h == "youtube.com" || h.endsWith(".youtube.com")
    fun isMaps(u: Uri): Boolean {
        val h = host(u); val p = u.path ?: ""
        return h == "maps.google.com" || h == "maps.app.goo.gl" || (isGoogle(h) && p.startsWith("/maps"))
    }

    private fun ext(u: Uri) = (u.path ?: "").lowercase().substringAfterLast('.', "")
    private fun badHost(h: String) = adult.any { h.contains(it) } || videoHosts.any { h == it || h.endsWith(".$it") }
    fun blockedRequest(u: Uri) = badHost(host(u)) || ext(u) in videoExt

    fun blockReason(u: Uri): String? {
        val h = host(u); val p = (u.path ?: "").lowercase()
        inner(u)?.let { i -> blockReason(i)?.let { return it } }
        return when {
            adult.any { h.contains(it) } -> "Adult site block kora"
            videoHosts.any { h == it || h.endsWith(".$it") } -> "Video site block kora"
            ext(u) in videoExt -> "Video block kora"
            proxySite(u) -> "Proxy/VPN site block kora"
            otherEngine(u) -> "Ei search engine block kora. Shudhu Google, Bing, DuckDuckGo cholbe"
            unknownEngine(u) -> "Ei search engine e Safe Search force kora jay na, tai block kora"
            isGoogle(h) && (p.startsWith("/safesearch") || p.startsWith("/preferences") || p.contains("setprefs")) -> "Safe Search setting block kora"
            isGoogle(h) && (u.getQueryParameter("tbm") == "vid" || u.getQueryParameter("udm") in setOf("7", "39")) -> "Video search block kora"
            h.endsWith("bing.com") && p.startsWith("/videos") -> "Video search block kora"
            else -> null
        }
    }

    fun badDownload(name: String, mime: String?): Boolean {
        val e = name.substringAfterLast('.', "").lowercase()
        val m = (mime ?: "").lowercase()
        return e in videoExt || e in apkExt || m.startsWith("video/") || m in videoMime
    }

    private fun withParam(u: Uri, k: String, v: String): Uri {
        val b = u.buildUpon().clearQuery()
        for (n in u.queryParameterNames) if (n != k) for (x in u.getQueryParameters(n)) b.appendQueryParameter(n, x)
        return b.appendQueryParameter(k, v).build()
    }

    /** Safe Search force: rewrite hole notun Uri dey, na hole null. */
    fun forceSafe(u: Uri): Uri? {
        val h = host(u); val p = u.path ?: ""
        return when {
            isGoogle(h) && p == "/search" && u.getQueryParameter("safe") != "active" -> withParam(u, "safe", "active")
            h.endsWith("bing.com") && (p.startsWith("/search") || p.startsWith("/images")) && u.getQueryParameter("adlt") != "strict" -> withParam(u, "adlt", "strict")
            h.endsWith("duckduckgo.com") && u.getQueryParameter("q") != null && u.getQueryParameter("kp") != "1" -> withParam(u, "kp", "1")
            else -> null
        }
    }

    /** Page e video element/iframe/play shob kill. */
    val JS = """
(function(){if(window.__sb)return;window.__sb=1;
try{HTMLMediaElement.prototype.play=function(){try{this.pause()}catch(e){};return Promise.reject(new DOMException('blocked','NotAllowedError'))}}catch(e){}
try{window.MediaSource=undefined;window.ManagedMediaSource=undefined;window.RTCPeerConnection=undefined;window.webkitRTCPeerConnection=undefined}catch(e){}
var H=/youtube|youtu\.be|vimeo|dailymotion|twitch|tiktok|facebook\.com\/plugins\/video|jwplayer|rumble|bilibili/i;
function k(){document.querySelectorAll('video').forEach(function(e){try{e.pause()}catch(x){};e.remove()});
document.querySelectorAll('iframe,embed,object').forEach(function(e){if(H.test(e.src||e.data||''))e.remove()})}
k();new MutationObserver(k).observe(document,{childList:true,subtree:true});document.addEventListener('DOMContentLoaded',k)})();
"""

    val READ = """
(function(){var t=[];document.querySelectorAll('h1,h2,h3,p').forEach(function(e){var s=e.innerText.trim();
if(s.length>2)t.push('<'+e.tagName+'>'+s.replace(/</g,'&lt;')+'</'+e.tagName+'>')});
document.body.innerHTML='<div style="max-width:700px;margin:auto;padding:16px;font:18px/1.6 sans-serif">'+t.join('')+'</div>'})();
"""
}
