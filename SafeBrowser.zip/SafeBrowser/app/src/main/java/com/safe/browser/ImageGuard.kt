package com.safe.browser

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.util.LruCache
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import org.tensorflow.lite.DataType
import org.tensorflow.lite.Interpreter
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/**
 * Explicit image detect kore blur kore dey. Model: app/src/main/assets/nsfw.tflite
 * (224x224 input, 5 output: drawings, hentai, neutral, porn, sexy) ba 2 output (safe, nsfw).
 */
object ImageGuard {
    private var itp: Interpreter? = null
    val ready get() = itp != null
    private val cache = LruCache<String, Boolean>(2000)
    private val imgExt = setOf("jpg", "jpeg", "png", "webp", "avif", "bmp", "heic")
    private const val THRESHOLD = 0.5f // kom korle aro strict (beshi image blur hobe)
    private const val MIN_SIDE = 100   // choto icon check hoy na

    fun init(c: Context) {
        try {
            val b = c.assets.open("nsfw.tflite").readBytes()
            val bb = ByteBuffer.allocateDirect(b.size).order(ByteOrder.nativeOrder()); bb.put(b); bb.rewind()
            itp = Interpreter(bb)
        } catch (e: Exception) { itp = null }
    }

    fun process(r: WebResourceRequest, cookie: String?): WebResourceResponse? {
        if (itp == null || r.method != "GET") return null
        val u = r.url
        if (u.scheme != "http" && u.scheme != "https") return null
        val ext = (u.path ?: "").substringAfterLast('.', "").lowercase()
        val acc = r.requestHeaders["Accept"] ?: ""
        if (!(acc.startsWith("image/") || ext in imgExt)) return null
        return try {
            val key = u.toString()
            val c = URL(key).openConnection() as HttpURLConnection
            c.connectTimeout = 5000; c.readTimeout = 8000; c.instanceFollowRedirects = true
            r.requestHeaders.forEach { (k, v) -> if (!k.equals("Accept-Encoding", true) && !k.equals("Range", true)) c.setRequestProperty(k, v) }
            if (cookie != null) c.setRequestProperty("Cookie", cookie)
            val code = c.responseCode
            val ct = (c.contentType ?: "").lowercase().substringBefore(';').trim()
            if (code !in 200..299 || !ct.startsWith("image/") || "svg" in ct || "gif" in ct || "icon" in ct || c.contentLength > 20_000_000) { c.disconnect(); return null }
            val data = c.inputStream.use { it.readBytes() }
            val hd = HashMap<String, String>()
            c.headerFields.forEach { (k, v) ->
                if (k != null && v.isNotEmpty() && !k.equals("content-encoding", true) && !k.equals("content-length", true) && !k.equals("transfer-encoding", true)) hd[k] = v.joinToString(", ")
            }
            val msg = (c.responseMessage ?: "").ifBlank { "OK" }
            c.disconnect()
            val unsafe = cache.get(key) ?: classify(data).also { cache.put(key, it) }
            if (!unsafe) WebResourceResponse(ct, null, code, msg, hd, ByteArrayInputStream(data))
            else {
                val b = blur(data)
                if (b != null) WebResourceResponse("image/jpeg", null, 200, "OK", mapOf("Access-Control-Allow-Origin" to "*"), ByteArrayInputStream(b))
                else WebResourceResponse("text/plain", "utf-8", 403, "Blocked", emptyMap(), ByteArrayInputStream(ByteArray(0)))
            }
        } catch (e: Exception) { null }
    }

    private fun classify(data: ByteArray): Boolean {
        val ip = itp ?: return false
        try {
            val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(data, 0, data.size, o)
            if (o.outWidth < MIN_SIDE || o.outHeight < MIN_SIDE) return false
            o.inJustDecodeBounds = false; o.inSampleSize = maxOf(1, minOf(o.outWidth, o.outHeight) / 448)
            val bmp = BitmapFactory.decodeByteArray(data, 0, data.size, o) ?: return false
            val t = ip.getInputTensor(0); val sh = t.shape(); val h = sh[1]; val w = sh[2]
            val sb = Bitmap.createScaledBitmap(bmp, w, h, true)
            val px = IntArray(w * h); sb.getPixels(px, 0, w, 0, 0, w, h)
            val quant = t.dataType() == DataType.UINT8
            val buf = ByteBuffer.allocateDirect(w * h * 3 * (if (quant) 1 else 4)).order(ByteOrder.nativeOrder())
            for (p in px) for (s in intArrayOf(16, 8, 0)) {
                val v = (p shr s) and 255
                if (quant) buf.put(v.toByte()) else buf.putFloat(v / 255f)
            }
            val n = ip.getOutputTensor(0).shape()[1]
            val out = Array(1) { FloatArray(n) }
            synchronized(ip) { ip.run(buf, out) }
            val s = out[0]
            return when (n) {
                5 -> s[1] + s[3] + s[4] > THRESHOLD
                2 -> s[1] > THRESHOLD
                else -> false
            }
        } catch (e: Exception) { return false }
    }

    private fun blur(data: ByteArray): ByteArray? {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(data, 0, data.size, o)
        o.inJustDecodeBounds = false; o.inSampleSize = maxOf(1, maxOf(o.outWidth, o.outHeight) / 800)
        val b = BitmapFactory.decodeByteArray(data, 0, data.size, o) ?: return null
        val small = Bitmap.createScaledBitmap(b, maxOf(1, b.width / 40), maxOf(1, b.height / 40), true)
        val big = Bitmap.createScaledBitmap(small, b.width, b.height, true)
        val bo = ByteArrayOutputStream(); big.compress(Bitmap.CompressFormat.JPEG, 60, bo)
        return bo.toByteArray()
    }
}
