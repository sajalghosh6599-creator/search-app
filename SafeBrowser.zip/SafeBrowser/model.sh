#!/bin/bash
# GitHub Actions e cholbe: NSFW model download -> .tflite convert
set -e
mkdir -p dl
cd dl
gh release download 1.1.0 -R GantMan/nsfw_model
for z in *.zip; do [ -f "$z" ] && unzip -q -o "$z" || true; done
cd ..
find dl -maxdepth 3 | head -50
pip install -q "tensorflow==2.14.1" "tensorflow_hub==0.15.0" "numpy<2"
python convert.py dl app/src/main/assets/nsfw.tflite
ls -la app/src/main/assets/
