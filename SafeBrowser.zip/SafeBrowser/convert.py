import sys, os, glob
import tensorflow as tf
import tensorflow_hub as hub

src, out = sys.argv[1], sys.argv[2]
h5 = glob.glob(src + "/**/*.h5", recursive=True)
sm = [os.path.dirname(p) for p in glob.glob(src + "/**/saved_model.pb", recursive=True)]
print("h5:", h5, "saved_model:", sm)

def pick(items):
    good = [p for p in items if "224" in p and "mobilenet" in p.lower()]
    return (good or items)[0]

if h5:
    p = pick(h5); print("using", p)
    m = tf.keras.models.load_model(p, custom_objects={"KerasLayer": hub.KerasLayer}, compile=False)
    conv = tf.lite.TFLiteConverter.from_keras_model(m)
elif sm:
    p = pick(sm); print("using", p)
    conv = tf.lite.TFLiteConverter.from_saved_model(p)
else:
    raise SystemExit("Model file paoa jay ni")

data = conv.convert()
open(out, "wb").write(data)
print("saved", out, len(data))
